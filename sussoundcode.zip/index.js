      function play1() {
        var audio1 = new Audio('y2mate.com - Allahu Akbar With Explosion Sound Effect (1)-[AudioTrimmer.com].mp3');
        audio1.play();
      }
      function play2() {
        var audio2 = new Audio('y2mate.com - Chamber Voicelines ValorantEN-[AudioTrimmer.com].mp3');
        audio2.play();
      }
      function play3() {
        var audio3 = new Audio('y2mate.com - Valorant sounds-[AudioTrimmer.com](1).mp3');
        audio3.play();
      }
      function play4() {
        var audio4 = new Audio('y2mate.com - Valorant sounds-[AudioTrimmer.com] (2).mp3');
        audio4.play();
      }
      function play5() {
        var audio5 = new Audio('y2mate.com - Valorant sounds-[AudioTrimmer.com] (3).mp3');
        audio5.play();
      } 
      function play6() {
        var audio6 = new Audio('y2mate.com - Valorant sounds-[AudioTrimmer.com] (4).mp3');
        audio6.play();
      } 
      function play7() {
        var audio7 = new Audio('y2mate.com - Valorant sounds-[AudioTrimmer.com] (5).mp3');
        audio7.play();
      } 